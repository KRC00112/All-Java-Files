/**
 * 
 */
/**
 * @author lenovo
 *
 */
module gui_calculator {
	requires java.desktop;
}
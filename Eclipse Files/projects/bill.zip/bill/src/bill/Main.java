package bill;

public class Main {

	public static void main(String[] args) {
		
		
		Frame frame=new Frame();
		// TODO Auto-generated method stub

	}

}

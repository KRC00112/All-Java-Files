/**
 * 
 */
/**
 * 
 */
module form {
	requires java.desktop;
}
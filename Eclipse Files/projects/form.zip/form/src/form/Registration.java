package form;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
public class Registration
{
public static void main (String [] args)
{
JFrame f = new JFrame();
JLabel l1,l2,l3,l4,l5;
l1= new JLabel("Name");
l1.setBounds(10,50,50,40);
final JTextField tf1= new JTextField();
tf1.setBounds(50,50,300,20);
l2= new JLabel("Age");
l2.setBounds(10,100,100,40);
final JTextField tf2= new JTextField();
tf2.setBounds(50,110,300,20);
l3= new JLabel("Phone Number");
l3.setBounds(10,150,100,40);
final JTextField tf3= new JTextField();
tf3.setBounds(50,160,300,20);
l4= new JLabel("Qualification");
l4.setBounds(10,200,100,40);
final JTextArea tf4= new JTextArea();
tf4.setBounds(50,210,150,200);
l5= new JLabel("Address");
l5.setBounds(10,450,100,40);
final JTextArea tf5= new JTextArea();
tf5.setBounds(50,460,150,200);
JRadioButton rb1,rb2;
rb1=new JRadioButton("Single post");
rb1.setBounds(10,710,100,40);
rb2=new JRadioButton("Multiple post");
rb2.setBounds(10,730,100,40);
JButton b= new JButton("apply");
b.setBounds(50,750,50,500);
ButtonGroup bg=new ButtonGroup();
bg.add(rb1);
bg.add(rb2);
f.add(l1);
f.add(l2);
f.add(l3);
f.add(l4);
f.add(l5);
f.add(tf1);
f.add(tf2);
f.add(tf3);
f.add(tf4);
f.add(tf5);
f.add(rb1);
f.add(rb2);
f.add(b);
f.setSize(1000,1000);
f.setLayout(null);
f.setVisible(true);
b.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
if(rb1.isSelected())
{
JOptionPane.showMessageDialog(f,tf1.getText()+ " "+tf3.getText()+" ; Amount to be paid is 1000; applied successfully");
}
if(rb2.isSelected())
{
JOptionPane.showMessageDialog(f,tf1.getText()+ " "+tf3.getText()+" ; Amount to be paid is 1200; applied successfully");
}
}
});
}
}